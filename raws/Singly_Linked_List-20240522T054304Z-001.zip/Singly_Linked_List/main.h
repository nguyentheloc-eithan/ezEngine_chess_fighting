#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <math.h>

#include<vector>
#include<stack>
#include<queue>
#include<map>


using namespace std;

#endif