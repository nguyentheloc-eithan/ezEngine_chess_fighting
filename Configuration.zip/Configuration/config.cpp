#include "main.h"
using namespace std;

void configuration(string fileName)
{
    // TODO:
}