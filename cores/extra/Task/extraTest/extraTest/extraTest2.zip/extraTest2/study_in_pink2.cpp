// Map xét điều kiện col row = 0 tránh cấp phát lỗi
// getCount của BaseBag theo test của thầy là trả về chuỗi "Bag[count="+<size>+";]"